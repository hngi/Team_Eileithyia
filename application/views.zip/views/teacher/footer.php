 <div class="footer">
      <p><i class="fa fa-heart"></i>&nbsp;Copyright Thyla E-Learning. All Rights Reserved 2019.</p>
  </div>

</div>

</body>
</html>